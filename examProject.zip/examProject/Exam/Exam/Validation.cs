﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
   public class Validation
    {
        public bool MinMax(string str)
        {
            return str.Length > 3 && str.Length <= 50;
        }

        public bool Test2(string str)
        {
            return str.Length > 9 && str.Length <= 35;
        }
        public bool Test3(string str)
        {
            try
            {
                if (str.Contains(".") || (str.Contains(",")))
                    return false;
                var a = Convert.ToInt32(str);
                if (a < 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }
            catch
            {
                return false;
            }
        }
    }
}
