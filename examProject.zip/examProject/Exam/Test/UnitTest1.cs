using Exam;
using NUnit.Framework;

namespace Test
{
    public class Tests
    {
        Validation validation = new Validation();
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Testsimboulcount()
        {
            Assert.AreEqual(true,validation.MinMax("1234567"));
        }

        [Test]
        public void Testwithcount()
        {
            Assert.AreEqual(true, validation.Test2("1234567890"));
        }

        [Test]
        public void Pozitiv()
        {
            Assert.AreEqual(true, validation.Test3("6"));
        }
    }
}